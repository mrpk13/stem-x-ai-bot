import g4f.api

if __name__ == "__main__":
    g4f.api.run_api(debug=True)
