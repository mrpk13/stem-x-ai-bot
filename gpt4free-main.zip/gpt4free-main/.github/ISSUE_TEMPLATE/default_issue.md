---
name: New Issue
about: 'Please use this template !!'
title: ''
labels: bug
assignees: xtekky

---

**Known Issues** // delete this
- you.com issue / fix: use proxy, or vpn, your country is probably flagged
- forefront account creation error / use your own session or wait for fix


**Bug description**
What did you do, what happened, which file did you try to run, in which directory
Describe what you did after downloading repo, such as moving to this repo, running this file.

ex.
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Environment**
- python version
- location ( are you in a cloudfare flagged country ) ?

**Additional context**
Add any other context about the problem here.
